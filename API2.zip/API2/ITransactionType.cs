﻿namespace DemoDapper.Abstractions
{
    public interface ITransactionType
    {
    }
}