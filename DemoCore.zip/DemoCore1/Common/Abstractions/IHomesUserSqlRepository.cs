﻿using Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Abstractions
{
    public interface IHomesUserSqlRepository : IAbstractRepository<HomesUser>
    {
    }
}
