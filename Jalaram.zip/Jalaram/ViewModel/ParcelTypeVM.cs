﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JalaramTravels.ViewModel
{
    public class ParcelTypeVM
    {
        public Int32 ParcelTypeID { get; set; }

        public String ParcelTypeName { get; set; }
    }
}