﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JalaramTravels.ViewModel
{
    public class ParcelContainerVM
    {
        public Int32 ParcelContainerID { get; set; }

        public String ParcelContainerName { get; set; }
    }
}