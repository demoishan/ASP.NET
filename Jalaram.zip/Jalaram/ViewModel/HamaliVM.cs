﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JalaramTravels.ViewModel
{
    public class HamaliVM
    {
        public Int32 ID { get; set; }
        public decimal Hamali { get; set; }
    }
}