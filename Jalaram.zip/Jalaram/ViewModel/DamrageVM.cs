﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JalaramTravels.ViewModel
{
    public class DamrageVM
    {
        public Int32 ID { get; set; }
        public decimal Damrage { get; set; }
    }
}