import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-starter2',
  templateUrl: './starter2.component.html',
  styleUrls: ['./starter2.component.scss']
})
export class Starter2Component implements OnInit, OnDestroy {

  body: HTMLBodyElement = document.getElementsByTagName('body')[0];

  constructor() { }

  ngOnInit() {
    this.body.classList.add('sidebar-mini');
  }

  ngOnDestroy() {
    // remove the the body classes
    this.body.classList.remove('sidebar-mini');
  }

}
