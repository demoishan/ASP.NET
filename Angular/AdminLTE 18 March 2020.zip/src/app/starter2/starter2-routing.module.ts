import { Content2Component } from './starter2/content/content.component';
import { Page1Component } from './starter2/page1/page1.component';
import { Page2Component } from './starter2/page2/page2.component';
import { Page3Component } from './starter2/page3/page3.component';
import { StudentComponent } from './starter2/student/student.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Starter2Component } from './starter2/starter2.component';


const routes: Routes = [
  {
    path: '',
    component: Starter2Component,
    children: [
      { path: '', component: Content2Component },
      { path: 'page1', component: Page1Component },
      { path: 'page2', component: Page2Component },
      { path: 'page3', component: Page3Component },
      { path: 'student', component: StudentComponent }
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Starter2RoutingModule { }
