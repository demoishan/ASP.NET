import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HeroesComponent } from './admin/heroes/heroes.component';
import { StuComponent } from './admin/stu/stu.component';
import { DetailComponent } from './admin/detail/detail.component';
import { AdminComponent } from './admin/admin.component';
import { CategoriesComponent } from './admin/categories/categories.component';
import { GridComponent } from './admin/grid/grid.component';
import { Dt1Component } from './admin/dt/dt1/dt1.component';
import { Dt2Component } from './admin/dt/dt2/dt2.component';
import { Dt3Component } from './admin/dt/dt3/dt3.component';
import { Dt4Component } from './admin/dt/dt4/dt4.component';
import { DtdetailComponent } from './admin/dt/dtdetail/dtdetail.component';

const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      { path: 'dt1', component: Dt1Component },
      { path: 'dt2', component: Dt2Component },
      { path: 'dt3', component: Dt3Component },
      { path: 'dt4', component: Dt4Component },
      { path: 'dtdetail', component: DtdetailComponent },
      { path: 'heroes', component: HeroesComponent },
      { path: 'stu', component: StuComponent },
      { path: 'details', component: DetailComponent },
      { path: 'categories', component: CategoriesComponent },
      { path: 'grid', component: GridComponent },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
