import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DataTablesModule } from 'angular-datatables';
import { AdminRoutingModule } from './admin-routing.module';

import { ControlSideBarComponent } from './admin/layout/control-side-bar/control-side-bar.component';
import { MainSideBarComponent } from './admin/layout/main-side-bar/main-side-bar.component';
import { NavBarComponent } from './admin/layout/nav-bar/nav-bar.component';
import { FooterComponent } from './admin/layout/footer/footer.component';

import { AdminComponent } from './admin/admin.component';
import { ContentComponent } from './admin/content/content.component';
import { HeroesComponent } from './admin/heroes/heroes.component';
import { StuComponent } from './admin/stu/stu.component';
import { DetailComponent } from './admin/detail/detail.component';
import { CategoriesComponent } from './admin/categories/categories.component';
import { GridComponent } from './admin/grid/grid.component';
import { Dt1Component } from './admin/dt/dt1/dt1.component';
import { Dt2Component } from './admin/dt/dt2/dt2.component';
import { Dt3Component } from './admin/dt/dt3/dt3.component';
import { Dt4Component } from './admin/dt/dt4/dt4.component';
import { DtdetailComponent } from './admin/dt/dtdetail/dtdetail.component';

@NgModule({
  declarations: [
    AdminComponent,
    ContentComponent,
    HeroesComponent,
    ControlSideBarComponent,
    MainSideBarComponent,
    NavBarComponent,
    FooterComponent,
    StuComponent,
    DetailComponent,
    CategoriesComponent,
    GridComponent,
    Dt1Component,
    Dt2Component,
    Dt3Component,
    DtdetailComponent,
    Dt4Component
  ],
  imports: [
    CommonModule,
    DataTablesModule,
    AdminRoutingModule
  ]
})
export class AdminModule { }
