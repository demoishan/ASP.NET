import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Starter2Component } from './starter2.component';

describe('Starter2Component', () => {
  let component: Starter2Component;
  let fixture: ComponentFixture<Starter2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Starter2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Starter2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
