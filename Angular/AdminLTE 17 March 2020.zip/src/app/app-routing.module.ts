import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { LoginComponent } from './login/login.component';
import { StuComponent } from './starter/starter/stu/stu.component';

const routes: Routes = [
  //{    path: '', loadChildren: () => import('./starter/starter.module').then(m => m.StarterModule)  },
  // {path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule)},
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
  { path: 'starter', loadChildren: () => import('./starter/starter.module').then(m => m.StarterModule) },
  { path: 'details', loadChildren: () => import('./starter/starter.module').then(m => m.StarterModule) },
  { path: 'shop', loadChildren: () => import('./shop/shop.module').then(m => m.ShopModule) },
  // {  path: 'Admin',loadChildren: () => import('./starter2/starter2.module').then(m => m.Starter2Module)} 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }