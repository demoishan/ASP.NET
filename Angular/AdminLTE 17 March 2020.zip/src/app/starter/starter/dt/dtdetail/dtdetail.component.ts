import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dtdetail',
  templateUrl: './dtdetail.component.html',
  styleUrls: ['./dtdetail.component.scss']
})
export class DtdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
