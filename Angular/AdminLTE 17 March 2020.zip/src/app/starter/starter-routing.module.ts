import { ContentComponent } from './starter/content/content.component';
import { HeroesComponent } from './starter/heroes/heroes.component';
import { StuComponent } from './starter/stu/stu.component';
import { DetailComponent } from './starter/detail/detail.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StarterComponent } from './starter/starter.component';
import { CategoriesComponent } from './starter/categories/categories.component';
import { GridComponent } from './starter/grid/grid.component';
import { Dt1Component } from './starter/dt/dt1/dt1.component';
import { Dt2Component } from './starter/dt/dt2/dt2.component';
import { Dt3Component } from './starter/dt/dt3/dt3.component';
import { Dt4Component } from './starter/dt/dt4/dt4.component';
import { DtdetailComponent } from './starter/dt/dtdetail/dtdetail.component';

const routes: Routes = [
      { path: '', component: StarterComponent },
      { path: 'heroes', component: HeroesComponent },
      { path: 'stu', component: StuComponent },
      { path: 'details', component: DetailComponent },
      { path: 'categories', component: CategoriesComponent },
      { path: 'grid', component: GridComponent },
      { path: 'dt1', component: Dt1Component },
      { path: 'dt2', component: Dt2Component },
      { path: 'dt3', component: Dt3Component },
      { path: 'dt4', component: Dt4Component },
      { path: 'dtdetail', component: DtdetailComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StarterRoutingModule { }