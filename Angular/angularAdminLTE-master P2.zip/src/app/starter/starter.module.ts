import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoutingModule } from './starter-routing.module';
import { StarterComponent } from './starter/starter.component';
import { ContentComponent } from './starter/content/content.component';
import { HeroesComponent } from './starter/heroes/heroes.component';
import { ControlSideBarComponent } from './starter/control-side-bar/control-side-bar.component';
import { MainSideBarComponent } from './starter/main-side-bar/main-side-bar.component';
import { NavBarComponent } from './starter/nav-bar/nav-bar.component';
import { FooterComponent } from './starter/footer/footer.component';
import { StuComponent } from './starter/stu/stu.component';
import { DetailComponent } from './starter/detail/detail.component';
import { CategoriesComponent } from './starter/categories/categories.component';
import { GridComponent } from './starter/grid/grid.component';
import { Dt1Component } from './starter/dt/dt1/dt1.component';
import { DataTablesModule } from 'angular-datatables';
import { Dt2Component } from './starter/dt/dt2/dt2.component';
import { Dt3Component } from './starter/dt/dt3/dt3.component';
import { DtdetailComponent } from './starter/dt/dtdetail/dtdetail.component';
import { Dt4Component } from './starter/dt/dt4/dt4.component';


@NgModule({
  declarations: [
    StarterComponent,
    ContentComponent,
    HeroesComponent,
    ControlSideBarComponent,
    MainSideBarComponent,
    NavBarComponent,
    FooterComponent,
    StuComponent,
    DetailComponent,
    CategoriesComponent,
    GridComponent,
    Dt1Component,
    Dt2Component,
    Dt3Component,
    DtdetailComponent,
    Dt4Component
  ],
  imports: [
    CommonModule,
    DataTablesModule,
    RoutingModule
  ]
})
export class StarterModule { }
