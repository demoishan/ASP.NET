import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dt1',
  templateUrl: './dt1.component.html',
  styleUrls: ['./dt1.component.scss']
})
export class Dt1Component implements OnInit {
  dtOptions: DataTables.Settings = {};
  constructor() { }

  ngOnInit(): void {
    this.dtOptions = {
      pagingType: 'full_numbers'
    };
  }

}
