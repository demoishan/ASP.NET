import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-control-side-bar',
  templateUrl: './control-side-bar.component.html',
  styleUrls: ['./control-side-bar.component.scss']
})
export class ControlSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
