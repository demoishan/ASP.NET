import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-side-bar2',
  templateUrl: './control-side-bar.component.html',
  styleUrls: ['./control-side-bar.component.scss']
})
export class ControlSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
