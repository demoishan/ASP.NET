import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Starter2RoutingModule } from './starter2-routing.module';
import { Starter2Component } from './starter2/starter2.component';
import { SidebarComponent } from './starter2/sidebar/sidebar.component';
import { NavbarComponent } from './starter2/navbar/navbar.component';
import { FooterComponent } from './starter2/footer/footer.component';
import { Content2Component } from './starter2/content/content.component';
import { ControlSideBarComponent } from './starter2/control-side-bar/control-side-bar.component';
import { MainSideBarComponent } from './starter2/main-side-bar/main-side-bar.component';
import { StudentComponent } from './starter2/student/student.component';
import { Page1Component } from './starter2/page1/page1.component';
import { Page2Component } from './starter2/page2/page2.component';
import { Page3Component } from './starter2/page3/page3.component';
import { ContentComponent } from '../starter/starter/content/content.component';


@NgModule({
  declarations: [
    Starter2Component,
    SidebarComponent,
    NavbarComponent,
    FooterComponent,
    ContentComponent,
    ControlSideBarComponent,
    MainSideBarComponent,
    StudentComponent,
    Page1Component,
    Page2Component,
    Page3Component],
  imports: [
    CommonModule,
    Starter2RoutingModule
  ]
})
export class Starter2Module { }
