import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

// import { DataTablesModule } from 'angular-datatables';
import { AppComponent } from './app.component';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    // DataTablesModule,
    AppRoutingModule
  ],
  providers: [Title ],
  bootstrap: [AppComponent]
})
export class AppModule { }
